//Новые методы перебора массивов
'use strict';


//примеры промисов

/* console.log('Запрос данных...');

const req = new Promise(function(resolve, reject){
	
	setTimeout(()=> {
		
		console.log('Подготовка данных');
		
		const out = 'Данные загружены';
		
		resolve(out);
		
		//reject();
		
	},3000)
});

req.then((out) => {
	
	return new Promise ((resolve, reject) => {
		
		 out = out + ' полностью!'
		 
		 resolve(out);

});

})
.then((out) => {
	
		return out = out + " Теперь точно!!!"
		
})
.then((out) => {
	setTimeout(()=>{
		console.log(out);
	}, 3000);
})
.catch(() => console.log('Ошибка!!!'));
 */

/* ///GET запрос и XMLHttpRequest



 const inp = document.querySelector('input');

const btn = document.querySelectorAll('button'); */
/*
btn[0].addEventListener('click', () => {
	
	const request = new XMLHttpRequest();
	
	console.log(request);
	
	request.open('GET', coeff.json);
	
	request.setRequestHeader('Content-type', 'application/json', 'charset=utf-8');
	
	request.send();
	
	request.addEventListener('load', () => {
		
		if (request.status === 200){
			
			const data = JSON.parse(request.response);
			
			inp.value = inp.value * data.data;
			
		}else{
			
			inp.value = 'Хуета то какая!'
			
		}
		
	});
}); */



/* const funch = () => {

inp.value = inp.value * 2;

const newInp = document.createElement('input'),
	
	  body = document.querySelector('body');

body.appendChild(newInp);

btn[1].style.backgroundColor = 'red';

btn[1].style.color = 'white';

btn[1].removeEventListener('click', funch);

btn[1].addEventListener('click', () => {
	
	let newArr = newInp.value.split('')
			
	let arr = '';
	
		newArr.map((item) => {
		
		item = item*1;
		
		if (item >=0 && item < 10) {
			
			 arr = arr + item;
			 
		} else if (isNaN(item)) {
			
			arr = '';
			
		}
		
		
		});
		
		
		if (arr === ''){
			
			newInp.value = "ERROR"
			
			newInp.style.backgroundColor = 'red';
			
			newInp.style.color = 'white';
			
			timeOut(newInp);
			
		} else {
			
		newInp.value = arr * 2;
		
		newInp.style.backgroundColor = 'green';
		
		timeOut(newInp);
		
		}
	
});

}


btn[1].addEventListener('click', funch);


function timeOut(clear){
	setTimeout(() => {
		clear.style.backgroundColor = 'white';
		clear.style.color = 'black';
		clear.value = "";
	}, 1500)
};
 */


//const divParent = document.createElement('div');

/* const divParent = document.querySelector('.divParent')

	const	body = document.querySelector('body');
	  
	  divParent.style.width = '200px';
	  
	  divParent.style.height = '200px';
	  
	  divParent.style.border = '10px solid';
	  
	  divParent.style.borderColor = 'green';
	  
	  
	  divParent.classList.add('divParent');
	  
	  
	  
	  body.appendChild(divParent);
	  
	  
	  for (let i = 0; i < 1000; i++){
		  
		  const  divChilde = document.createElement('input');
		  
		  divChilde.style.width = '1px';
	  
	      divChilde.style.height = '1px';
		  
		//  divChilde.style.borderColor = 'white';
		  
		 divChilde.style.border = '0px solid';
		 
		 divChilde.style.paddings = '0px';
		  
		   divChilde.style.backgroundColor = 'red';
		   
		   divChilde.classList.add('divChild');
		  
		  
		  divParent.appendChild(divChilde);
		  
		  
	  } */
	  


/* function main (arg) {
	
	console.log(arg);
	
	if (arg < 10) {
	
	setTimeout(() => {
		
		console.clear();
		
		main(arg + 1);
		
	}, 1000);
	
	} else {
		
		console.clear();
		
		console.log('ВСЕ!')
		
	}
	
}

const arg = +prompt('Введите начало отсчета');

main(arg); */

const body = document.querySelector('body');

const div = document.createElement('div');

/* body.appendChild(div)

class Fucking{
	constructor(one, two, three){
		this.firs = one;
		this.second = two;
		this.threed = three;
		this.render();
	}
	render(){
				
				div.innerHTML = `<h1>${this.firs}, ${this.second}, ${this.threed} FUCKING</h1>`;
						
								
	}
}

let a = 0;

 setInterval(() => {
	 
	 
	a++;
	const classNew = new Fucking(a, 2, 3);
},1000);
 */




//console.log(classNew);

/* let a1 = document.querySelector('.one'),
	  b1 = document.querySelector('.two'),
	  c1 = document.querySelector('.three'),
	  d1 = document.querySelector('.four'),
	  e1 = document.querySelector('.five');
 const divNew = document.createElement('div');
	 
	  
const input = document.querySelectorAll('input');



for(let i = 0; i < input.length; i++){
	input[i].addEventListener('input', main)
}
	  
	  
	  
	function main (e) {
		
		setTimeout(fuck, 500);
		
		console.log(e.target)
		
		e.target.classList.add('fuck')
		
			setTimeout(() => {
				
					e.target.classList.remove('fuck')
					
			},1500)
	}  
	  
	  
	function fuck (e) {
		 	 
		 
		 let D = +b1.value * +b1.value - 4 * +a1.value * + c1.value;
		 
		if(+a1.value === 0){
			
			const x3 = (-+c1.value/+b1.value);
						
			e1.value = `Корень равен ${x3}`
			
		}else{
		 
		if (D < 0) {
			
			e1.value = 'Корней нет'
			
		}else if (D === 0){
			
			const x1 = - +b1.value/2 * +a1.value
			
			e1.value = `Корень равен ${x1}`
			
		}else{
			
			const x1 = (-+b1.value + Math.sqrt(D))/(2 * +a1.value);
			
			const x2 = (-+b1.value - Math.sqrt(D))/(2 * +a1.value);
			
			e1.value = `Корни равны ${x1} и ${x2}`
		}
		}
		
		let plusMinus1 = "+",
			 plusMinus2 = "+";
		 
		 if(+b1.value < 0){
			 plusMinus1 = "";
		 if (+c1.value < 0){
			 plusMinus2 = "";
		 }
		 if((+b1.value > 0) && (+c1.value > 0))
			 plusMinus1 = plusMinus2 = "+";
		 }
		 if((+b1.value > 0) && (+c1.value < 0)){
			 plusMinus2 = "";
		 }
		 
		 let A = +a1.value,
		     B = +b1.value,
			 C = +c1.value,
			 x2 = 'x2',
			 x = 'x';
			 
			 if (A === 0 && B == 0){
				 A = '';
				 x2 = '';
				 plusMinus1 = '';
				 B = '';
				 x = '';
				 plusMinus2 = '';
			 }
			 if((B === 0) && (C < 0)){
				 B = '';
				 x = '';
				 plusMinus1 = '';
				 plusMinus2 = '';
			 }
			 if((A === 0) && (C === 0)){
				 A = '';
				 x2 = '';
				 C = '';
				 plusMinus1 = '';
				 plusMinus2 = '';
			 }
			 if (A === 1){
				 A = '';
			 }
			 if (A === -1){
				 A = '-';
			 }
			 if (B === 1){
				 B = '';
			 }
			 if (B === -1){
				 B = '';
				 plusMinus1 = '-';
			 }
			 
			 if(A === 0){
				 A = '';
				 x2 = '';
				 plusMinus1 = '';
			 }
			 if(B === 0){
				 B = '';
				 x = '';
				 plusMinus1 = '';
			 }
			if(C === 0){
				 C = '';
				 plusMinus2 = '';
				
			 }
			 if(e1.value === 'Корней нет'){
				 
				 e1.classList.add('fuckTwo');
				 
				  e1.classList.remove('fuck');
				  
			 }else{
				 
				 e1.classList.add('fuck');
				 
				 e1.classList.remove('fuckTwo');
				 
			 }
			 
			 setTimeout(() => {
				 
				  e1.classList.remove('fuck');
				  
				   e1.classList.remove('fuckTwo');
				   
			 },1000)
			 
			 
		 
		 divNew.innerText = `${A}${x2} ${plusMinus1} ${B}${x} ${plusMinus2} ${C}= 0`
		
		body.appendChild(divNew);
		
		
	 }; */
	 
	 
	 
	 
	//примеры промисов

/* console.log('Запрос данных...');

const req = new Promise(function(resolve, reject){
	
	setTimeout(()=> {
		
		console.log('Подготовка данных');
		
		const out = 'Данные загружены';
		
		resolve(out);
		
		//reject();
		
	},3000)
});

req.then((out) => {
	
	return new Promise ((resolve, reject) => {
		
		 out = out + ' полностью!'
		 
		 resolve(out);

});

})
.then((out) => {
	
		return out = out + " Теперь точно!!!"
		
})
.then((out) => {
	setTimeout(()=>{
		console.log(out);
	}, 3000);
})
.catch(() => console.log('Ошибка!!!'));
//.finally(() => console.log('It is fucking bitch')); */
 
 
 
/* const isMomHappy = true;

// Промис
const willIGetNewPhone = new Promise(
    (resolve, reject) => { // fat arrow
        if (isMomHappy) {
            const phone = {
                  brand: 'Samsung',
                  color: 'black'
                          };
						  
            resolve(phone);
			
        } else {
            const reason = new Error('mom is not happy');
            reject(reason);
        }

    }
);

const showOff = function (phone) {
    const message = 'Hey friend, I have a new ' +
                phone.color + ' ' + phone.brand + ' phone';
    return Promise.resolve(message);
};

// Вызываем промис
const askMom = function () {
    willIGetNewPhone
        .then(showOff)
        .then(fulfilled => console.log(fulfilled)) // fat arrow
        .catch(error => console.log(error.message)); // fat arrow
};

askMom(); */


/* const div1 = document.querySelector(".one"),
	  h1 = document.querySelector(".one h1"),
	  div2 = document.querySelector(".one div"),
	  div3 = document.querySelector(".one div div");

console.log(div1);

div1.addEventListener('click', (event) => {
	
	if (event.target == h1){
		console.log('h1');
	} else if (event.target == div2){
		console.log('div2');
	} else if (event.target == div3){
		console.log('div3');
	} else {
		console.log('div_parent');
	};
	
	//console.log(event);
});

class Max {
	
	constructor(name, age) {
		
		this.name = name;
		
		this.age = age;
		
	}
	
	say(){
		console.log(`Имя: ${this.name}, Возраст: ${this.age}`);
		this.name = 'Dima';
	}
	
	
	
}

const max = new Max('Maxim', 33);



max.say();



function CoffeeMachine(power, capacity){
	
	let waterAmount = 0;
	
	let WATER_HEAT_CAPACITY = 4200;
	
	function getTimeToBoil(){
		return waterAmount *  WATER_HEAT_CAPACITY * 80 / power;
	}
	
	
	this.setWaterAmount = function(amount){
		if (amount < 0){
			throw new Error("Значение должно быть положительным");
		}
		if (amount > capacity){
			throw new Error ("Нельзя залить воды больше, чем " + capacity);
		}
		
		waterAmount = amount;
		
		this.run();
		
	};
	
	function onReady(){
		alert('Кофе готов');
	}
	
	this.run = function(){
		setTimeout(onReady, getTimeToBoil());
		
	}
	
}

let coffeeMachine = new CoffeeMachine(1000, 500);


console.log(coffeeMachine);

coffeeMachine.setWaterAmount(1);

//coffeeMachine.run(); */



const objUrl = {
	
	"Рисунок 1": {
		img: '1.jpg',
		width: '100px',
		height: '80px'
		},
	"Рисунок 2": {
		img: '2.jpg',
		width: '100px',
		height: '80px'
		},
	"Рисунок 3": {
		img: '3.jpg',
		width: '100px',
		height: '80px'
		},
	"Рисунок 4": {
		img: '4.jpg',
		width: '100px',
		height: '80px'
		},
	"Рисунок 5": {
		img: '5.jpg',
		width: '100px',
		height: '80px'
		},
	"Рисунок 6": {
		img: '6.jpg',
		width: '100px',
		height: '80px'
		},
	"Рисунок 7": {
		img: '7.jpg',
		width: '100px',
		height: '80px'
		},
	"Рисунок 8": {
		img: '8.jpg',
		width: '100px',
		height: '80px'
		},
	"Рисунок 9": {
		img: '1.jpg',
		width: '100px',
		height: '80px'
		},
	"Рисунок 10": {
		img: '2.jpg',
		width: '100px',
		height: '80px'
		},
	"Рисунок 11": {
		img: '3.jpg',
		width: '100px',
		height: '80px'
		},
	"Рисунок 12": {
		img: '4.jpg',
		width: '100px',
		height: '80px'
		},
	"Рисунок 13": {
		img: '5.jpg',
		width: '100px',
		height: '80px'
		},
	"Рисунок 14": {
		img: '6.jpg',
		width: '100px',
		height: '80px'
		},
	"Рисунок 15": {
		img: '7.jpg',
		width: '100px',
		height: '80px'
		},
	"Рисунок 16": {
		img: '8.jpg',
		width: '100px',
		height: '80px'
		}
	
};


class NewElement{
	
// принимаем объект с данными
	
	constructor(textCont, classElementParent){
		
		this.textCont = textCont; 
		
		this.classElementParent = classElementParent;
		
		this.render(this.parenContainer(), this.processingObj());
		
	}
	
// метод обработки данных

	processingObj () {
		
		let data = Object.entries(this.textCont);
			
		const heading = data.map(item => item[0]); // названия изображений
		
		const url = data.map(item => item[1].img); // url
		
		const width = data.map(item => item[1].width); // ширина изображения
		
		const height = data.map(item => item[1].height); // высота изображения
		
		return data = [heading, url, width, height]; //выходной массив с массивами данных	
				
	}
	
// создаем родительский DIV
	
	parenContainer() { 
		
		const div = document.createElement('div'),
			  body = document.querySelector('body');
			  
		if(localStorage.getItem('color')){
			body.style.backgroundColor = localStorage.getItem('color');
		} else {
			body.style.backgroundColor = "Lavender";
		}	  
			  
		div.classList.add(this.classElementParent);
		
		div.style.display = 'flex';
		
		body.prepend(div); 
		
		return div;
		 
	}
	
// рендерим изображения на страницу
	
	render(div, data) {		
		
	for(let i = 0; i < data[3].length; i++){
		
		let random = '';
		
		if(!parseInt(data[1][i])){
		
		while(random > 8 || random == 0) {
			random = Math.round((Math.random()*10));
		} 
		
		}
		
		console.log(random);
		
		dataRead(data[0][i], random + data[1][i], data[2][i], data[3][i], div);
		
	};
	
	const img = document.querySelectorAll('img');
		
	img.forEach(item => {
		
		item.addEventListener('mouseenter', () => {
			
			item.style.width = '250px';
			item.style.height = '170px';
			item.style.transition = '1s all';
		
		});
		
		item.addEventListener('mouseout', () => {
			
			item.style.width = '100px';
			item.style.height = '80px';
			item.style.borderRadius = '0%';
		
		});
		
		item.addEventListener('click', () => {
			
			let color = Math.round(Math.random() * 16777215).toString(16);
			
			if (color.length < 6){
				let index = 6 - color.length
				for(let i = 0; i <= index; i++){
					color = (color + Math.round(Math.random() * 10)).substr(0, 6);
					
				}  
			}
			localStorage.setItem('color','#' + color)
			body.style.backgroundColor = '#' + color;
		
		});
		
	});
		
		
	function dataRead (textCont, url, width, height, div) {	
		
		const divChilde = document.createElement('div');
			
		divChilde.innerHTML = `
		
		<p style="color: white">${textCont}
		
			<img src = "${url}" width = "${width}" height = "${height}"/>
		
		</p>
		
		`;
		
		div.append(divChilde);	
				
	}	
		
	}	
	
}


const objUrl1 = {
	
	"Рисунок 1": {
		img: 'https://cdn.pixabay.com/photo/2014/02/27/16/10/tree-276014__480.jpg',
		width: '100px',
		height: '80px'
		},
	"Рисунок 2": {
		img: 'https://cdn.pixabay.com/photo/2014/01/22/19/44/flower-field-250016__340.jpg',
		width: '100px',
		height: '80px'
		},
	"Рисунок 3": {
		img: 'https://cdn.pixabay.com/photo/2017/02/01/22/02/mountain-landscape-2031539__340.jpg',
		width: '100px',
		height: '80px'
		},
	"Рисунок 4": {
		img: 'https://cdn.pixabay.com/photo/2016/02/27/06/43/cherry-blossom-tree-1225186__340.jpg',
		width: '100px',
		height: '80px'
		},
	"Рисунок 5": {
		img: 'https://cdn.pixabay.com/photo/2016/07/11/15/43/woman-1509956__340.jpg',
		width: '100px',
		height: '80px'
		},
	"Рисунок 6": {
		img: 'https://images.pexels.com/photos/992734/pexels-photo-992734.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500',
		width: '100px',
		height: '80px'
		},
	"Рисунок 7": {
		img: 'https://images.pexels.com/photos/60909/rose-yellow-flower-petals-60909.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500',
		width: '100px',
		height: '80px'
		},
	"Рисунок 8": {
		img: 'https://images.pexels.com/photos/3576112/pexels-photo-3576112.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500',
		width: '100px',
		height: '80px'
		},
	"Рисунок 9": {
		img: 'https://images.pexels.com/photos/4623061/pexels-photo-4623061.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500',
		width: '100px',
		height: '80px'
		},
	"Рисунок 10": {
		img: 'https://images.pexels.com/photos/56866/garden-rose-red-pink-56866.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500',
		width: '100px',
		height: '80px'
		},
	"Рисунок 11": {
		img: 'https://images.pexels.com/photos/386015/pexels-photo-386015.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500',
		width: '100px',
		height: '80px'
		},
	"Рисунок 12": {
		img: 'https://images.pexels.com/photos/1233414/pexels-photo-1233414.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500',
		width: '100px',
		height: '80px'
		},
	"Рисунок 13": {
		img: 'https://images.pexels.com/photos/15286/pexels-photo.jpg?auto=compress&cs=tinysrgb&dpr=1&w=500',
		width: '100px',
		height: '80px'
		},
	"Рисунок 14": {
		img: 'https://images.pexels.com/photos/2258536/pexels-photo-2258536.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500',
		width: '100px',
		height: '80px'
		},
	"Рисунок 15": {
		img: 'https://images.pexels.com/photos/1509582/pexels-photo-1509582.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500',
		width: '100px',
		height: '80px'
		},
	"Рисунок 16": {
		img: 'https://images.pexels.com/photos/2113566/pexels-photo-2113566.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500',
		width: '100px',
		height: '80px'
		}
	
};

const objUrl2 = {
	
	"Рисунок 1": {
		img: '.jpg',
		width: '100px',
		height: '80px'
		},
	"Рисунок 2": {
		img: '.jpg',
		width: '100px',
		height: '80px'
		},
	"Рисунок 3": {
		img: '.jpg',
		width: '100px',
		height: '80px'
		},
	"Рисунок 4": {
		img: '.jpg',
		width: '100px',
		height: '80px'
		},
	"Рисунок 5": {
		img: '.jpg',
		width: '100px',
		height: '80px'
		},
	"Рисунок 6": {
		img: '.jpg',
		width: '100px',
		height: '80px'
		},
	"Рисунок 7": {
		img: '.jpg',
		width: '100px',
		height: '80px'
		},
	"Рисунок 8": {
		img: '.jpg',
		width: '100px',
		height: '80px'
		},
	"Рисунок 9": {
		img: '.jpg',
		width: '100px',
		height: '80px'
		},
	"Рисунок 10": {
		img: '.jpg',
		width: '100px',
		height: '80px'
		},
	"Рисунок 11": {
		img: '.jpg',
		width: '100px',
		height: '80px'
		},
	"Рисунок 12": {
		img: '.jpg',
		width: '100px',
		height: '80px'
		},
	"Рисунок 13": {
		img: '.jpg',
		width: '100px',
		height: '80px'
		},
	"Рисунок 14": {
		img: '.jpg',
		width: '100px',
		height: '80px'
		},
	"Рисунок 15": {
		img: '.jpg',
		width: '100px',
		height: '80px'
		},
	"Рисунок 16": {
		img: '.jpg',
		width: '100px',
		height: '80px'
		}
	
};




let newImg = new NewElement(objUrl2, 'parentContainer_1');
    newImg = new NewElement(objUrl, 'parentContainer_2');
	newImg = new NewElement(objUrl, 'parentContainer_3');
	newImg = new NewElement(objUrl, 'parentContainer_4');
	newImg = new NewElement(objUrl, 'parentContainer_5');
	newImg = new NewElement(objUrl, 'parentContainer_6');
	newImg = new NewElement(objUrl, 'parentContainer_7');
	newImg = new NewElement(objUrl, 'parentContainer_8');
	newImg = new NewElement(objUrl, 'parentContainer_9');
	newImg = new NewElement(objUrl, 'parentContainer_10');




